package com.example.travelbooking.service;

import com.example.travelbooking.entities.Payments;

public interface PaymentService {
		Payments getPaymentById(int paymentId );
		Payments addPayment(Payments payment);
		Payments updateDb(int paymentId, Payments payment);
		void deleteDb(int paymentId);
		
	}

